package com.masache.masachetesis.models;

public enum TipoEnum {
    RESERVA,
    CLASE,
    TUTORIA
}
