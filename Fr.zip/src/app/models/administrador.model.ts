export class Administrador {
  idAdministrador: number;
  nombreAdministrador: string;
  apellidoAdministrador: string;
  correoAdministrador: string;
  idInstitucional: string;;

  constructor() {
    this.idAdministrador = 0;
    this.nombreAdministrador = '';
    this.apellidoAdministrador = '';
    this.correoAdministrador = '';
    this.idInstitucional = '';
  }
}
