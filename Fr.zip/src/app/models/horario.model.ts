export interface Horario {
  idHorario?: number;
  franjasHorario?: string[];
  diasHorario?: string[];
}
