export class Card {
    icon: string;
    color: string;
    title: string;
    count: string;
}
